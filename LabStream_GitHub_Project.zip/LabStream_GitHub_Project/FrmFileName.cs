using System;
using System.IO;
using System.Windows.Forms;

namespace LabStream;

public class FrmFileName : Form
{
    public static string SetFileName = "MyFile.txt";
    private readonly TextBox txtFileName = new() { Left = 25, Top = 45, Width = 260 };
    private readonly Button btnOkay = new() { Left = 205, Top = 85, Width = 80, Text = "Okay" };

    public FrmFileName()
    {
        Text = "FrmFileName";
        Width = 335;
        Height = 170;
        StartPosition = FormStartPosition.CenterParent;
        Controls.Add(new Label { Left = 25, Top = 20, AutoSize = true, Text = "Enter file name:" });
        Controls.Add(txtFileName);
        Controls.Add(btnOkay);
        btnOkay.Click += BtnOkay_Click;
        AcceptButton = btnOkay;
    }

    private void BtnOkay_Click(object? sender, EventArgs e)
    {
        string name = txtFileName.Text.Trim();
        if (string.IsNullOrWhiteSpace(name))
        {
            MessageBox.Show("Please enter a file name.");
            return;
        }

        // Remove an extension if the user already typed .txt.
        if (name.EndsWith(".txt", StringComparison.OrdinalIgnoreCase))
            name = name[..^4];

        foreach (char invalid in Path.GetInvalidFileNameChars())
            name = name.Replace(invalid, '_');

        SetFileName = name + ".txt";
        DialogResult = DialogResult.OK;
        Close();
    }
}
