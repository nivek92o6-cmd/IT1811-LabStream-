using System;
using System.IO;
using System.Windows.Forms;

namespace LabStream;

public class FrmRegistration : Form
{
    private readonly TextBox txtStudentNo = new() { Left = 115, Top = 45, Width = 145 };
    private readonly ComboBox cmbProgram = new() { Left = 390, Top = 45, Width = 210, DropDownStyle = ComboBoxStyle.DropDownList };
    private readonly TextBox txtLastName = new() { Left = 115, Top = 85, Width = 145 };
    private readonly TextBox txtFirstName = new() { Left = 335, Top = 85, Width = 145 };
    private readonly TextBox txtMI = new() { Left = 525, Top = 85, Width = 55 };
    private readonly TextBox txtAge = new() { Left = 115, Top = 125, Width = 80 };
    private readonly ComboBox cmbGender = new() { Left = 390, Top = 125, Width = 145, DropDownStyle = ComboBoxStyle.DropDownList };
    private readonly DateTimePicker dtpBirthday = new() { Left = 115, Top = 165, Width = 180, Format = DateTimePickerFormat.Short };
    private readonly TextBox txtContact = new() { Left = 390, Top = 165, Width = 145 };
    private readonly Button btnRegister = new() { Left = 270, Top = 215, Width = 110, Text = "Register" };

    public FrmRegistration()
    {
        Text = "FrmRegistration";
        Width = 650;
        Height = 310;
        StartPosition = FormStartPosition.CenterScreen;

        AddLabel("Registration", 20, 10, 18);
        AddLabel("Student No.", 20, 48); Controls.Add(txtStudentNo);
        AddLabel("Program", 315, 48); Controls.Add(cmbProgram);
        AddLabel("Last Name", 20, 88); Controls.Add(txtLastName);
        AddLabel("First Name", 270, 88); Controls.Add(txtFirstName);
        AddLabel("M.I.", 495, 88); Controls.Add(txtMI);
        AddLabel("Age", 20, 128); Controls.Add(txtAge);
        AddLabel("Gender", 315, 128); Controls.Add(cmbGender);
        AddLabel("Birthday", 20, 168); Controls.Add(dtpBirthday);
        AddLabel("Contact No.", 315, 168); Controls.Add(txtContact);
        Controls.Add(btnRegister);

        cmbProgram.Items.AddRange(new object[] {
            "BS Information Technology", "BS Computer Science",
            "BS Information Systems", "BS Computer Engineering"
        });
        cmbProgram.SelectedIndex = 0;
        cmbGender.Items.AddRange(new object[] { "Male", "Female", "Prefer not to say" });
        cmbGender.SelectedIndex = 0;
        btnRegister.Click += BtnRegister_Click;
    }

    private void AddLabel(string text, int left, int top, int fontSize = 9)
    {
        Controls.Add(new Label
        {
            Text = text, Left = left, Top = top, AutoSize = true,
            Font = new System.Drawing.Font("Segoe UI", fontSize)
        });
    }

    private void BtnRegister_Click(object? sender, EventArgs e)
    {
        if (string.IsNullOrWhiteSpace(txtStudentNo.Text) ||
            string.IsNullOrWhiteSpace(txtLastName.Text) ||
            string.IsNullOrWhiteSpace(txtFirstName.Text))
        {
            MessageBox.Show("Please enter the student number, last name, and first name.");
            return;
        }

        if (!int.TryParse(txtAge.Text, out int age))
        {
            MessageBox.Show("Please enter a valid age.");
            return;
        }

        string studentNo = txtStudentNo.Text.Trim();
        string[] content =
        {
            $"Student No.:{studentNo}",
            $"Full Name:{txtLastName.Text.Trim()}, {txtFirstName.Text.Trim()}, {txtMI.Text.Trim()}",
            $"Program: {cmbProgram.Text}",
            $"Gender: {cmbGender.Text}",
            $"Age: {age}",
            $"Birthday: {dtpBirthday.Value:yyyy-MM-dd}",
            $"Contact No.{txtContact.Text.Trim()}"
        };

        string safeStudentNo = studentNo;
        foreach (char invalid in Path.GetInvalidFileNameChars())
            safeStudentNo = safeStudentNo.Replace(invalid, '_');

        string docPath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
        string filePath = Path.Combine(docPath, safeStudentNo + ".txt");

        try
        {
            using StreamWriter outputFile = new(filePath);
            foreach (string line in content)
                outputFile.WriteLine(line);

            MessageBox.Show($"Registration text file created:\n{filePath}", "Success");
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Could not create file: {ex.Message}", "Error");
        }
    }
}
