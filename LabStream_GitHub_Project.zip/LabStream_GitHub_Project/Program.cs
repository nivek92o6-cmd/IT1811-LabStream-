using System;
using System.Windows.Forms;

namespace LabStream;

internal static class Program
{
    [STAThread]
    static void Main()
    {
        ApplicationConfiguration.Initialize();
        Application.Run(new FrmLab1());
    }
}
