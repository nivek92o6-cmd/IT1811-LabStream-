using System;
using System.IO;
using System.Windows.Forms;

namespace LabStream;

public class FrmLab1 : Form
{
    private readonly TextBox txtInput = new() { Left = 25, Top = 55, Width = 330 };
    private readonly Button btnCreate = new() { Left = 25, Top = 100, Width = 100, Text = "Create" };

    public FrmLab1()
    {
        Text = "FrmLab1 - Creating Text File";
        Width = 410;
        Height = 205;
        StartPosition = FormStartPosition.CenterScreen;
        Controls.Add(new Label { Left = 25, Top = 25, AutoSize = true, Text = "Enter text:" });
        Controls.Add(txtInput);
        Controls.Add(btnCreate);
        btnCreate.Click += BtnCreate_Click;
    }

    private void BtnCreate_Click(object? sender, EventArgs e)
    {
        using var fileNameForm = new FrmFileName();
        if (fileNameForm.ShowDialog(this) != DialogResult.OK) return;

        string getInput = txtInput.Text;
        string docPath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
        string filePath = Path.Combine(docPath, FrmFileName.SetFileName);

        try
        {
            using StreamWriter outputFile = new(filePath);
            outputFile.WriteLine(getInput);
            MessageBox.Show($"Text file created successfully:\n{filePath}", "Success");
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Could not create file: {ex.Message}", "Error");
        }
    }
}
