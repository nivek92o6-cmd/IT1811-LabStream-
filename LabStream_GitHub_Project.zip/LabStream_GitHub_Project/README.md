# IT1811 Laboratory Exercise 1 — Creating Text File

A C# Windows Forms project based on the supplied laboratory handout.

## Requirements
- Windows
- Visual Studio 2022 or later
- .NET 8 SDK with the **.NET desktop development** workload

## Run
1. Extract the ZIP file.
2. Open `LabStream.csproj` in Visual Studio.
3. Build and run the project.
4. The app starts with `FrmLab1`. To open the registration challenge form, change `Application.Run(new FrmLab1());` in `Program.cs` to `Application.Run(new FrmRegistration());`.

## Output
Text files are saved in the current user's **Documents** folder.
