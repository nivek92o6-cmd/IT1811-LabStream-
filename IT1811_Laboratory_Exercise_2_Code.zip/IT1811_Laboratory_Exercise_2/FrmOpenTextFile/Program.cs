using System;
using System.Windows.Forms;

namespace IT1811_Laboratory_Exercise_2
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new FrmOpenTextFile());
        }
    }
}
