# IT1811 Laboratory Exercise 2
## Reading a File

This project follows the uploaded laboratory exercise:
- Form: FrmOpenTextFile
- ListView: lvShowText
- Button: btnOpen
- OpenFileDialog
- Reads a selected .txt file and displays each line in the ListView.

The Challenge Exercise in the handout requires the previous Laboratory Exercise 1 project, so that part is not included here.
